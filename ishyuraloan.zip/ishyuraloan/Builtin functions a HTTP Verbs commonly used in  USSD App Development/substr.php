<?php
    $phone_number = "0786580957";
    echo "+1". substr($phone_number, 1);
 ?>