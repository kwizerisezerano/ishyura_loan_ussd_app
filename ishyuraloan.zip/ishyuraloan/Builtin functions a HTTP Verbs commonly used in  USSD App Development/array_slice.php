<?php 
    $str = array(3,  6, 3, 0, 6, 4);
    var_dump(array_slice($str, 2, 2, true));
?>