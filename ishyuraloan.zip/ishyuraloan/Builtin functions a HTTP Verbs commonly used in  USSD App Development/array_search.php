<?php
    $ussdString = "1*2*5*0*8*1*12*0";
    $arr = array(1, 2, 3, 4, 5);
    var_dump (array_search("3", $arr));
?>