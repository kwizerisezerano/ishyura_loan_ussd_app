<?php
    $arr1 = array(1, 2, 3);
    $arr2 = array(4, 5, 6);
    $arr3 = array(7, 9, 9);

    var_dump(array_merge( $arr1,  $arr2,  $arr3));
?>