<?php
    $str = "123*9*3*4";
    $exploded = explode("*", $str);
    array_shift($exploded);

    var_dump($exploded);
?>