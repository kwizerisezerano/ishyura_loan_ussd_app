<?php
    echo $_POST['name'] . " is " . $_POST['age']. "years old"
?>