<?php
$str = "123*9*3*4";
var_dump(explode("*", $str));

?>