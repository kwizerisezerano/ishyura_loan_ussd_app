<?php
//1*3*99*5*1*12*99*1*2
    $text = $_POST['text'];
    $rm = new Remove($text);
    //echo "*". ;
    echo $rm->remove99();

    class Remove{
        var $str;
        function __construct($s){
            $this->str = $s;
        }
        public function remove99(){
            $explodeString = explode("*", $this->str);
            while(array_search("99", $explodeString) != false){
                $firstIndex = array_search("99", $explodeString);
                $explodeString = array_slice($explodeString, $firstIndex+1);
            }
            return join("*", $explodeString);
        }
        public function remove98(){
            $explodeString = explode("*", $this->str);
            while(array_search("98", $explodeString) != false){
                $firstIndex = array_search("98", $explodeString);
                array_splice($explodeString, $firstIndex, 1);
            }
            return join("*", $explodeString);
        }
    }
?>
