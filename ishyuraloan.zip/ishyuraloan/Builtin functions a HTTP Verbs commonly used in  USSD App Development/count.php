<?php
        $str = "123*9*3*4";
        $exploded = explode("*", $str);
        array_shift($exploded);
    
        $after_shift_array = count($exploded);
        
        echo $after_shift_array;
        var_dump($exploded);


?>