<?php
    $ussdString = "1*3*5*8*99*0";
    $ussdString_exploded = explode("*", $ussdString);
    //$ussdString_exploded_elem_removed =  $unset($ussdString_exploded[5]);
    unset($ussdString_exploded[4]);
    var_dump($ussdString_exploded);
?>