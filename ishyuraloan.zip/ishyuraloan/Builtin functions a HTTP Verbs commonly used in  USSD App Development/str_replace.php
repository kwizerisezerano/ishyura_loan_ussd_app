<?php
    $string = "*123*9#3*4#";
    $str_replacement = str_replace('#','*', $string);
    $str_change_and_add = substr($str_replacement,0, 10) . "#";
    echo $str_change_and_add; 
?>