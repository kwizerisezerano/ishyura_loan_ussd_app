<?php
    $arr = array(1, 3, 5);
    echo join("*", $arr);
?>