<?php
    $month = yearTomonth(4);
    echo $month;
    function yearTomonth(int $year){
        return $year * 12;
    }
?>