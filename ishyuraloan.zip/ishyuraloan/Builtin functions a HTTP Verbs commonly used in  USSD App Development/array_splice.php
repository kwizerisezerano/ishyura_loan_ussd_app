<?php
    $arr = array(2, 6, 1, 5, 6);
    array_splice($arr, 1, 2, array(8, 9));// If you don't specify array as a replacement of removed elements, replacement will never happen
    // ex:   array_splice($arr, 1, 2);
    print_r($arr);
?>